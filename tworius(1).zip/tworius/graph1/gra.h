#ifndef GRA_H_INCLUDED
#define GRA_H_INCLUDED
#include <iostream>

using namespace std;

#define child(s) (s)->child
#define nextN(s) (s)->nextN
#define infoN(s) (s)->infoN
#define nextN(s) (s)->nextN
#define nextE(s) (s)->nextE
#define infoE(s) (s)->infoE
#define bobot(s) (s)->bobot

typedef string infotype;
typedef struct node *adrNode;
typedef struct edge *adrEdge;

typedef struct node{
    infotype infoN;
    adrEdge child;
    adrNode nextN;
};

typedef struct edge{
    infotype infoE;
    adrEdge nextE;
};

adrNode newNode(infotype x);
void addNode(adrNode &G, adrNode p);
adrNode findNode(adrNode G, infotype x);
void addEdge(adrNode &G, infotype x, infotype y);
bool isConnected(adrNode G, infotype x, infotype y);
void printGraph(adrNode G);
adrNode connect(adrNode g);
bool hasLoop(adrNode G, infotype x);
void printEdge(adrNode G);


#endif // GRA_H_INCLUDED
