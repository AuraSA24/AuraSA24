#include "gra.h"

adrNode newNode(infotype x){
    adrNode s = new node;
    infoN(s) = x;
    child(s) = NULL;
    nextN(s) = NULL;
    return s;
}

void addNode(adrNode &g, adrNode p){
    if(g == NULL){
        g = p;
    }else{
        nextN(p) = g;
        g = p;
    }
/*
    if (infoN(g) != NULL){
        adrNode j = infoN(g);
        while(nextN(j) != NULL){
            j = nextN(j);
        }
        nextN(j) = p;
    }else{
        infoN(g) = p;
    }
*/
}

adrNode findNode(adrNode g, infotype x){
    adrNode j = g;
    do{
        if(infoN(j) == x){
            return j;
        }else{
            j = nextN(j);
        }
    }while(j != NULL);

/*
    while(g != NULL){
        if infoN(j) == x{
            g = f;
            return j;
        }
        j = nextN(j);
    }
    return NULL;
*/
}

void addEdge(adrNode &g, infotype x, infotype y){

    adrNode j = findNode(g, x);
    adrEdge f = new edge;
    infoE(f) = y;
    nextE(f) = NULL;

    if(j != NULL){
        if(child(j) == NULL){
            child(j) = f;

        }else{
            adrEdge d = child(j);
            while(nextE(d) != NULL){
                d = nextE(d);
            }
            nextE(d) = f;
        }
    }

}

bool isConnected(adrNode g, infotype x, infotype y){
    adrNode j  = g;
    while(j != NULL){
        if(infoN(j) == x){
            adrEdge f = child(j);
            while(f != NULL){
                if(infoE(f) == y){
                    return true;
                }
                f = nextE(f);
            }
        }
        j = nextN(j);
    }
    return false;
}


void printGraph(adrNode g){
    adrNode j  = g;
    while(j != NULL){
        cout << infoN(j) << ":";
        adrEdge f = child(j);
        while(f != NULL){
            cout <<infoE(f);
            f = nextE(f);
        }
        cout << endl;
        j = nextN(j);
    }

}

adrNode connect(adrNode g){
    adrNode j = g;
    adrNode temp;
    adrEdge h;
    bool a = true;

    while(j != NULL){
        h = child(j);
        a = true;
        while(h != NULL && a){
            if(!isConnected(j, infoE(h), infoN(j))){
                a = false;
            }
            h = nextE(h);
        }
        if(h == NULL){
            return j;
        }
        j = nextN(j);

    }

}

bool hasLoop(adrNode g, infotype x){

}

void printEdge(adrNode g){
    adrNode j  = g;
    adrEdge f  = child(j);
    while(f != NULL){
        cout << infoE(f) << endl;
        f = nextE(f);
    }
}
