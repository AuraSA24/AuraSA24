#include "gra.h"

#include <iostream>

using namespace std;

int main()
{
    adrNode G = NULL;
    int i;

    addNode(G, newNode("Dago"));
    addNode(G, newNode("Cimanuk"));
    addNode(G, newNode("Supratman"));
    addNode(G, newNode("Ciumbuleuit"));
    addNode(G, newNode("Hegarmanah"));

    addEdge(G, "Hegarmanah", "Ciumbuleuit");
    addEdge(G, "Hegarmanah", "Cimanuk");
//    addEdge(G, 'Hegarmanah', 'Dago');
//
//    addEdge(G, 'Ciumbuleuit', 'Hegarmanah');
//    addEdge(G, 'Ciumbuleuit', 'Supratman');
//    addEdge(G, 'Ciumbuleuit', 'Cimanuk');
//    addEdge(G, 'Ciumbuleuit', 'Dago');
//
//    addEdge(G, 'Supratman', 'Ciumbuleuit');
//    addEdge(G, 'Supratman', 'Cimanuk');
//
//    addEdge(G, 'Cimanuk', 'Hegarmanah');
//    addEdge(G, 'Cimanuk', 'Ciumbuleuit');
//    addEdge(G, 'Cimanuk', 'Supratman');
//    addEdge(G, 'Cimanuk', 'Dago');
//
//    addEdge(G, 'Dago', 'Hegarmanah');
//    addEdge(G, 'Dago', 'Ciumbuleuit');
//    addEdge(G, 'Dago', 'Cimanuk');

    printGraph(G);
    cout << boolalpha;
    cout << "Apakah Hegarmanah dan Ciumbuleuit terhubung : " << isConnected(G, "Hegarmanah", "Ciumbuleuit") << "\n";

    adrNode f = connect(G);

    cout << infoN(f);
    adrEdge s = child(f);
    while(s != NULL){
        cout << infoE(s);
        s = nextE(s);
    }


    return 0;
}
